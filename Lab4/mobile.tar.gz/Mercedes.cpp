#include "Mercedes.h"

#include <iostream>

using namespace std;
/*
Mercedes& Mercedes::operator = (Mercedes &merc)
{
	return Pojazd(merc);
}
*/
